#! /bin/bash

yum install console_bridge gtest gtest-devel.aarch64 gmock-devel.aarch64 gtest.aarch64 libusb-devel.aarch64 yaml-cpp-devel.aarch64 uuid-devel.aarch64 fmt-devel.aarch64 glew-devel.aarch64 libpng.aarch64 libpcap-devel.aarch64 openmpi-devel.aarch64 qhull-devel.aarch64 lz4-devel.aarch64 libhdfs.aarch64 python3-nose2.noarch tmux hdf5-devel.aarch64 bzip2-devel.aarch64 jsoncpp-devel.aarch64 eigen3-devel.noarch libjpeg-turbo-devel.aarch64 libyaml-devel.aarch64 tbb-devel.aarch64 openjpeg-devel.aarch64 libv4l.aarch64 python opencv.aarch64
wait
exit 0
