  source /opt/ros/noetic/setup.bash 
  source /root/gy_stereo_openeuler2203_noetic_release/setup.bash
  export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/root/tangjp/install/lib
  # export ROS_MASTER_URI=http://10.101.31.100:11311
  # export ROS_IP=10.101.31.100
  roslaunch gy_stereo gy_stereo.launch 
